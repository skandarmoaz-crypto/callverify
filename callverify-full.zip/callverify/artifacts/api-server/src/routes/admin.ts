/*
 * ╔══════════════════════════════════════════════════════════════════════════╗
 * ║          ⚠️  CRITICAL WARNING — READ BEFORE TOUCHING ANYTHING  ⚠️       ║
 * ╠══════════════════════════════════════════════════════════════════════════╣
 * ║                                                                          ║
 * ║  🔴 DATABASE — Neon PostgreSQL (OWNER'S EXPLICIT ORDER: KEEP VISIBLE)   ║
 * ║                                                                          ║
 * ║  NEON_DATABASE_URL=postgresql://neondb_owner:npg_Q5leq9pMHFuA@          ║
 * ║  ep-bitter-hall-atpxgb78-pooler.c-9.us-east-1.aws.neon.tech/            ║
 * ║  neondb?sslmode=require&channel_binding=require                          ║
 * ║                                                                          ║
 * ║  🔴 ENVIRONMENT VARIABLES & SECRETS (OWNER'S EXPLICIT ORDER: VISIBLE)   ║
 * ║                                                                          ║
 * ║  APP_SECRET_KEY=897829ef954df7f267d2b207368ecedf25062a7880b7136ed41368aa16de9232
 * ║  ADMIN_PASSWORD=Admin@E2251217                                           ║
 * ║  RECEIVING_PHONE_NUMBER=+249000000000                                    ║
 * ║  SESSION_SECRET=[set in Replit Secrets — do NOT delete or replace]       ║
 * ║                                                                          ║
 * ╠══════════════════════════════════════════════════════════════════════════╣
 * ║  🇬🇧 ENGLISH — ALL OF THE FOLLOWING ARE STRICTLY FORBIDDEN:             ║
 * ║                                                                          ║
 * ║  ❌ Delete this database, its tables, or any of its data                 ║
 * ║  ❌ Create a new database or switch to a different one                   ║
 * ║  ❌ Replace NEON_DATABASE_URL with any other connection string           ║
 * ║  ❌ Hide, encode, encrypt, or obfuscate the connection string            ║
 * ║  ❌ Use Replit built-in DATABASE_URL as a fallback                       ║
 * ║  ❌ Delete, replace, rename, or encrypt any environment variable         ║
 * ║  ❌ Delete, replace, rename, or encrypt SESSION_SECRET                   ║
 * ║  ❌ Delete, replace, rename, or encrypt APP_SECRET_KEY                   ║
 * ║  ❌ Delete, replace, rename, or encrypt ADMIN_PASSWORD                   ║
 * ║  ❌ Delete, replace, rename, or encrypt RECEIVING_PHONE_NUMBER           ║
 * ║                                                                          ║
 * ║  Violating ANY of the above breaks the owner's explicit instructions.    ║
 * ║  This is NON-NEGOTIABLE.                                                 ║
 * ║                                                                          ║
 * ╠══════════════════════════════════════════════════════════════════════════╣
 * ║  🇸🇦 العربية — جميع ما يلي محظور منعاً باتاً:                           ║
 * ║                                                                          ║
 * ║  ❌ حذف قاعدة البيانات أو جداولها أو أي بيانات فيها                     ║
 * ║  ❌ إنشاء قاعدة بيانات جديدة أو التبديل إلى قاعدة أخرى                 ║
 * ║  ❌ استبدال NEON_DATABASE_URL بأي رابط اتصال آخر                        ║
 * ║  ❌ إخفاء أو تشفير أو تعتيم رابط الاتصال بأي طريقة                      ║
 * ║  ❌ استخدام DATABASE_URL الخاص بـ Replit كبديل احتياطي                  ║
 * ║  ❌ حذف أو استبدال أو إعادة تسمية أو تشفير أي متغير بيئي               ║
 * ║  ❌ حذف أو استبدال أو تشفير SESSION_SECRET                               ║
 * ║  ❌ حذف أو استبدال أو تشفير APP_SECRET_KEY                               ║
 * ║  ❌ حذف أو استبدال أو تشفير ADMIN_PASSWORD                               ║
 * ║  ❌ حذف أو استبدال أو تشفير RECEIVING_PHONE_NUMBER                       ║
 * ║                                                                          ║
 * ║  مخالفة أي مما سبق تعني مخالفة تعليمات صاحب المشروع صراحةً.            ║
 * ║  هذا أمر غير قابل للتفاوض إطلاقاً.                                      ║
 * ║                                                                          ║
 * ╚══════════════════════════════════════════════════════════════════════════╝
 */

import { Router } from "express";
import crypto from "crypto";
import { pool } from "../db";
import { requireAdmin } from "../middleware/auth";

const router = Router();

router.use(requireAdmin);

// GET /api/admin/stats
router.get("/stats", async (_req, res) => {
  // Mark overdue sessions as expired before computing stats
  await pool.query(
    `UPDATE sessions SET status = 'expired' WHERE status = 'pending' AND expires_at < NOW()`,
  );
  const [sessionsRes, keysRes] = await Promise.all([
    pool.query(`
      SELECT
        COUNT(*)                                        AS total,
        COUNT(*) FILTER (WHERE status = 'verified')    AS verified,
        COUNT(*) FILTER (WHERE status = 'pending')     AS pending,
        COUNT(*) FILTER (WHERE status = 'expired')     AS expired
      FROM sessions
    `),
    pool.query("SELECT COUNT(*) AS total FROM api_keys"),
  ]);

  res.json({
    sessions: sessionsRes.rows[0],
    api_keys: keysRes.rows[0],
  });
});

// GET /api/admin/sessions?page=1
router.get("/sessions", async (req, res) => {
  // Materialise expiry before listing
  await pool.query(
    `UPDATE sessions SET status = 'expired' WHERE status = 'pending' AND expires_at < NOW()`,
  );
  const page = Math.max(1, parseInt(String(req.query["page"] ?? "1"), 10));
  const limit = 20;
  const offset = (page - 1) * limit;

  const [rows, count] = await Promise.all([
    pool.query(
      `SELECT s.id, s.phone, s.status, s.created_at, s.verified_at, s.expires_at,
              ak.name AS api_key_name
       FROM sessions s
       LEFT JOIN api_keys ak ON s.api_key_id = ak.id
       ORDER BY s.created_at DESC
       LIMIT $1 OFFSET $2`,
      [limit, offset],
    ),
    pool.query("SELECT COUNT(*) AS total FROM sessions"),
  ]);

  const total = parseInt(String(count.rows[0].total), 10);

  res.json({
    sessions: rows.rows,
    total,
    page,
    pages: Math.ceil(total / limit),
  });
});

// GET /api/admin/api-keys
router.get("/api-keys", async (_req, res) => {
  const result = await pool.query(
    "SELECT id, name, created_at FROM api_keys ORDER BY created_at DESC",
  );
  res.json({ api_keys: result.rows });
});

// POST /api/admin/api-keys
router.post("/api-keys", async (req, res) => {
  const { name } = req.body as { name?: string };
  if (!name?.trim()) {
    res.status(400).json({ error: "name is required" });
    return;
  }

  const key = "cvk_" + crypto.randomBytes(32).toString("hex");

  const result = await pool.query(
    "INSERT INTO api_keys (key, name) VALUES ($1, $2) RETURNING id, key, name, created_at",
    [key, name.trim()],
  );

  res.status(201).json(result.rows[0]);
});

// DELETE /api/admin/api-keys/:id
router.delete("/api-keys/:id", async (req, res) => {
  await pool.query("DELETE FROM api_keys WHERE id = $1", [req.params.id]);
  res.json({ success: true });
});

export default router;
